from pytorch_lightning.overrides.data_parallel import LightningParallelModule  # noqa: F401
from pytorch_lightning.overrides.distributed import LightningDistributedModule  # noqa: F401
